<?php

/*
 *  ___            __  __
 * |_ _|_ ____   _|  \/  | ___ _ __  _   _
 *  | || '_ \ \ / / |\/| |/ _ \ '_ \| | | |
 *  | || | | \ V /| |  | |  __/ | | | |_| |
 * |___|_| |_|\_/ |_|  |_|\___|_| |_|\__,_|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author Muqsit
 * @link http://github.com/Muqsit
 *
*/

namespace me\frogas\custombackpack\muqsit\invmenu\utils;

use pocketmine\math\Vector3;

class HolderData{

	/** @var Vector3 */
	public $position;

	/** @var string|null */
	public $custom_name;

	public function __construct(Vector3 $position, ?string $custom_name){
		$this->position = $position;
		$this->custom_name = $custom_name;
	}
}