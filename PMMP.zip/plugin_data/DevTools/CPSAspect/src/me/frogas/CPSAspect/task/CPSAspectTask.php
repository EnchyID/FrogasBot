<?php

namespace me\frogas\CPSAspect\task;

use pocketmine\scheduler\Task as PluginTask;
use me\frogas\CPSAspect\CPSAspect;

class CPSAspectTask extends PluginTask {
	
	public function __construct(CPSAspect $plugin){
		$this->plugin = $plugin;
	}
	
	public function getPlugin(){
		return $this->plugin;
	}

	public function onRun($tick){
		$this->getPlugin()->sendTask();
	}
}