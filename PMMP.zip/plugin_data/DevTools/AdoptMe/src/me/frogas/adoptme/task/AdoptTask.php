<?php

namespace me\frogas\adoptme\task;

use pocketmine\scheduler\Task;
use me\frogas\adoptme\AdoptMe;

class AdoptTask extends Task {
	
	public function __construct(AdoptMe $plugin){
		$this->plugin = $plugin;
	}
	
	public function getLoader() : AdoptMe {
		return $this->plugin;
	}
	
	public function onRun(int $tick) : void {
		$this->getLoader()->setScoreboard();
		$this->getLoader()->addHud();
	}
}