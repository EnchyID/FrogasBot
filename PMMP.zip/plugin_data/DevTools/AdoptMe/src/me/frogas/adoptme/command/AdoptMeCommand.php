<?php

namespace me\frogas\adoptme\command;

use pocketmine\Player;
use pocketmine\command\{CommandSender, PluginCommand};
use pocketmine\utils\TextFormat as TF;
use pocketmine\math\Vector3;
use me\frogas\adoptme\form\{CustomForm, SimpleForm};
use me\frogas\adoptme\AdoptMe;
use me\frogas\avatar\Avatar;

class AdoptMeCommand extends PluginCommand {
	
	private $plugin, $queue;
	
	public function __construct(string $name, AdoptMe $plugin){
		parent::__construct($name, $plugin);
		$this->plugin = $plugin;
	}
	
	public function getLoader() : AdoptMe {
		return $this->plugin;
    }
	
	public function execute(CommandSender $player, string $label, array $args){
		if(!$player instanceof Player){
			return true;
		}
		$arg = array_shift($args);
		if(empty($arg)){
			$player->sendMessage($this->getLoader()->getPrefix() . "Usage /adoptme [setting|add|del]");
			return true;
		}
		switch($arg){
			case "setting":
		        $this->sendSetting($player, "Select an button to view new menu.");
		    break;
		    case "add":
		        $this->sendAdd($player, "Select an button to view new menu.");
		    break;
		    case "del":
		        $this->sendDel($player, "Select an button to unset baby.");
		    break;
		}
		return true;
	}
	
	public function sendSetting(Player $player, string $text){
		$form = new SimpleForm(function(Player $player, $data){
	        $result = $data;
	        if($result === null){
		        return true;
	         }
	         switch($result){
	             case 0:
		         break;
             }
	         if($data > 0){
		         $all = $this->getLoader()->getAdoptAll($player->getName());
		         $adopt = $all[$data - 1];
		         if($this->getLoader()->getServer()->getPlayer($adopt)){
			         $this->queue[$player->getName()] = $adopt;
			         $this->sendInfo($player, $adopt);
		         }else{
			         $this->sendSetting($player, TF::RED . "Error, Your baby by name " . $adopt . " offline on servers.");
			     }
	         }
        });
		$form->setTitle("( AdoptMe > Setting )");
		$form->setContent($text);
        $form->addButton("Close setting");
        foreach($this->getLoader()->getAdoptAll($player->getName()) as $adopt){
            if($this->getLoader()->getServer()->getPlayer($adopt)){
		        $form->addButton($adopt . TF::GRAY . TF::ITALIC . " (" . TF::AQUA . "Online" . TF::GRAY . ")", 0, "textures/avatar/" . Avatar::$used->get($adopt));
		    }else{
	            $form->addButton($adopt . TF::GRAY . TF::ITALIC . " (" . TF::RED . "Offline" . TF::GRAY . ")", 0, "textures/avatar/" . Avatar::$used->get($adopt));
	        }
	     }
        $form->sendToPlayer($player);
	}
	
	public function sendInfo(Player $player, string $adopt){
		$form = new CustomForm(function(Player $player, $data){
			$result = $data;
			if($result === null){
				return true;
			}
			$adopt = $this->getLoader()->getServer()->getPlayer($this->queue[$player->getName()]);
			if($result[0] == 0){
				$player->teleport($adopt);
			}
			if($result[0] == 1){
				$adopt->teleport($player);
			}
			if($result[0] == 2){
				$this->sendName($player, "This is name of change your baby name.");
			}
			if($result[0] == 3){
				if($adopt->isSleeping() == true){
					$adopt->stopSleep();
				}else{
		            $adopt->sleepOn(new Vector3(intval($adopt->getX()), intval($adopt->getY()), intval($adopt->getZ())));
		        }
			}
			if($result[0] == 4){
				$this->sendSettings($player, $adopt);
			}
		});
		$form->setTitle("( AdoptMe > Information )");
		$form->addDropdown("*" . TF::ITALIC . " Select an category:", ["* TELEPORT", "* TELEPORT OWNER", "* CHANGE NAME", "* SLEEP", "* SETTINGS"]);
		$form->sendToPlayer($player);
	}
	
	public function sendName(Player $player, string $label){
		$form = new CustomForm(function(Player $player, $data){
			$result = $data;
			if($result === null){
				return true;
			}
			$adopt = $this->getLoader()->getServer()->getPlayer($this->queue[$player->getName()]);
			$name = $adopt->getName();
			if(empty($result[1])){
				$this->sendName($player, TF::RED . "Error, you must enter an new name, please not empty input.");
				return true;
			}
			$player->sendMessage($this->getLoader()->getPrefix() . "Success change name of " . $name . " to " . $result[1]);
			$adopt->setNameTag($result[1]);
		});
		$adopt = $this->getLoader()->getServer()->getPlayer($this->queue[$player->getName()]);
	    $name = $adopt->getName();
		$form->setTitle("( AdoptMe > Name )");
		$form->addLabel($label);
		$form->addInput("*" . TF::ITALIC . " Enter new name:", "", $name);
		$form->sendToPlayer($player);
	}
	
	public function sendAdd(Player $player, string $text){
		$form = new SimpleForm(function(Player $player, $data){
	        $result = $data;
	        if($result === null){
		        return true;
	         }
	         switch($result){
	             case 0:
		         break;
             }
	         if($data > 0){
		         $all = $this->getLoader()->getOnlinePlayers();
		         $online = $all[$data - 1];
		         $name = $this->getLoader()->getServer()->getPlayer($online);
		         if($this->getLoader()->getServer()->getPlayer($online)){
			         $this->queue[$player->getName()] = $online;
			         $this->queue[$online] = $player->getName();
			         $this->sendAdopt($name, $player->getName());
		         }else{
			         $this->sendAdd($player, TF::RED . "Error, Request by name " . $online . " offline on servers.");
			     }
	         }
        });
		$form->setTitle("( AdoptMe > Add )");
		$form->setContent($text);
        $form->addButton("Close add");
        foreach($this->getLoader()->getOnlinePlayers() as $online){
            $form->addButton($online . TF::GRAY . TF::ITALIC . " (" . TF::AQUA . "Online" . TF::GRAY . ")" . TF::RESET . TF::EOL . TF::AQUA . "Tap To Adopt", 0, "textures/avatar/" . Avatar::$used->get($online));
	     }
        $form->sendToPlayer($player);
	}
	
	public function sendAdopt(Player $player, string $name){
		$form = new SimpleForm(function(Player $player, $data){
		    $result = $data;
	        if($result === null){
		        return true;
	         }
	         $name = $this->getLoader()->getServer()->getPlayer($this->queue[$player->getName()]);
	         switch($result){
	             case 0:
	                 $this->getLoader()->setOwnerBaby($name, 0.5, 0, $player->getName(), 0);
		         break;
		         case 1:
		         break;
             }
         });
         $form->setTitle("( AdoptMe > Request Adopt )");
         $form->setContent(TF::AQUA . "You must request to adopt your from " . TF::RED . $name . TF::WHITE . " Select accept or deny.");
         $form->addButton("ACCEPT");
         $form->addButton("DENY");
         $form->sendToPlayer($player);
     }
     
     public function sendDel(Player $player, string $text){
		$form = new SimpleForm(function(Player $player, $data){
	        $result = $data;
	        if($result === null){
		        return true;
	         }
	         switch($result){
	             case 0:
		         break;
             }
	         if($data > 0){
		         $all = $this->getLoader()->getAdoptAll($player->getName());
		         $adopt = $all[$data - 1];
		         $this->getLoader()->delBabyOwner($player, $adopt);
	         }
        });
		$form->setTitle("( AdoptMe > Delete )");
		$form->setContent($text);
        $form->addButton("Close delete");
        foreach($this->getLoader()->getAdoptAll($player->getName()) as $adopt){
            if($this->getLoader()->getServer()->getPlayer($adopt)){
		        $form->addButton($adopt . TF::GRAY . TF::ITALIC . " (" . TF::AQUA . "Online" . TF::GRAY . ")", 0, "textures/avatar/" . Avatar::$used->get($adopt));
		    }else{
	            $form->addButton($adopt . TF::GRAY . TF::ITALIC . " (" . TF::RED . "Offline" . TF::GRAY . ")", 0, "textures/avatar/" . Avatar::$used->get($adopt));
	        }
	     }
        $form->sendToPlayer($player);
	}
	
	public function sendSettings(Player $player, string $adopt){
		$form = new CustomForm(function(Player $player, $data){
			$result = $data;
			if($result === null){
				return true;
			}
			$adopt = $this->getLoader()->getServer()->getPlayer($this->queue[$player->getName()]);
			$name = $adopt->getName();
			if($result[1] == true){
				$this->getLoader()->setAdoptSetting($player->getName(), $name, true, $result[1], $result[3]);
			}
			if($result[1] == false){
				$this->getLoader()->setAdoptSetting($player->getName(), $name, false, $result[1], $result[3]);
			}
			if($result[2] == true){
				$this->getLoader()->setAdoptSetting($player->getName(), $name, $result[1], true, $result[3]);
			}
			if($result[2] == false){
				$this->getLoader()->setAdoptSetting($player->getName(), $name, $result[1], false, $result[3]);
			}
			if($result[3] == true){
				$this->getLoader()->setAdoptSetting($player->getName(), $name, $result[1], $result[2], true);
			}
			if($result[3] == false){
				$this->getLoader()->setAdoptSetting($player->getName(), $name, $result[1], $result[2], false);
			}
		});
		$adopt = $this->getLoader()->getServer()->getPlayer($this->queue[$player->getName()]);
	    $name = $adopt->getName();
		$form->setTitle("( AdoptMe > Settings )");
		$form->addLabel("Setting baby of " . $name . ".");
		if($this->getLoader()->getMovementSetting($player->getName(), $name) == true){
			$form->addToggle("* Allow baby movement", false);
		}else{
			$form->addToggle("* Allow baby movement", true);
		}
		if($this->getLoader()->getDamagerSetting($player->getName(), $name) == true){
			$form->addToggle("* Allow owner damage baby", false);
		}else{
		    $form->addToggle("* Allow owner damage baby", true);
		}
		if($this->getLoader()->getScoreboardSetting($player->getName(), $name) == true){
			$form->addToggle("* Allow baby scoreboard", false);
		}else{
		    $form->addToggle("* Allow baby scoreboard", true);
		}
		$form->sendToPlayer($player);
	}
}