<?php

namespace shock95x\auctionhouse\utils;

class Locale {

	public function __construct() {
	}

}