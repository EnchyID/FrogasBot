<?php

namespace OguzhanUmutlu\ComplexPets\entities\types;

use OguzhanUmutlu\ComplexPets\entities\PetEntity;

class PigPet extends PetEntity {
    public const NETWORK_ID = self::PIG;
    protected function initEntity(): void {
        parent::initEntity();
    }

    public function getName(): string {
        return "PigPet";
    }
}