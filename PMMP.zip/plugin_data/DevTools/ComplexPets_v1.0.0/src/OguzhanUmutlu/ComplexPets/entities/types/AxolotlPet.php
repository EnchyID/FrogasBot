<?php

namespace OguzhanUmutlu\ComplexPets\entities\types;

use OguzhanUmutlu\ComplexPets\entities\PetEntity;
use pocketmine\network\mcpe\protocol\AddActorPacket;
use pocketmine\Player;

class AxolotlPet extends PetEntity {
    public $riderHeight = 0.5;
    protected function initEntity(): void {
        parent::initEntity();
    }

    public function getName(): string {
        return "AxolotlPet";
    }
    protected function sendSpawnPacket(Player $player): void {
        $pk = new AddActorPacket();
        $pk->entityRuntimeId = $this->getId();
        $pk->type = "minecraft:axolotl";
        $pk->position = $this->asVector3();
        $pk->motion = $this->getMotion();
        $pk->yaw = $this->yaw;
        $pk->headYaw = $this->yaw;
        $pk->pitch = $this->pitch;
        $pk->attributes = $this->attributeMap->getAll();
        $pk->metadata = $this->propertyManager->getAll();
        $player->dataPacket($pk);
        $this->armorInventory->sendContents($player);
    }
}