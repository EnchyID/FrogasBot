package me.frogas.firstplugin;

import cn.nukkit.Player;
import cn.nukkit.plugin.PluginBase;
import cn.nukkit.event.Listener;
import cn.nukkit.command.*;

public class FirstPlugin extends PluginBase implements Listener {
	
	public void onEnable(){
		this.getServer().getPluginManager().registerEvents(this, this);
		this.getServer().getLogger().info("Enable by @Frogas");
	}
	
	public boolean onCommand(CommandSender player, Command cmd, String label, String[] args){
		switch(cmd.getName()){
			case "test":
			    if(player instanceof Player){
				    if(args.length == 0){
					    player.sendMessage("Working!!");
					    return true;
					}
					return true;
				}
			break;
		}
		return true;
	}
}