<?php

namespace OguzhanUmutlu\ComplexPets;

use BadMethodCallException;
use OguzhanUmutlu\ComplexPets\libs\dktapps\pmforms\CustomForm;
use OguzhanUmutlu\ComplexPets\libs\dktapps\pmforms\CustomFormResponse;
use OguzhanUmutlu\ComplexPets\libs\dktapps\pmforms\element\Dropdown;
use OguzhanUmutlu\ComplexPets\libs\muqsit\invmenu\InvMenuHandler;
use OguzhanUmutlu\ComplexPets\entities\PetEntity;
use OguzhanUmutlu\ComplexPets\entities\PetNBT;
use OguzhanUmutlu\ComplexPets\entities\types\AxolotlPet;
use OguzhanUmutlu\ComplexPets\entities\types\BatPet;
use OguzhanUmutlu\ComplexPets\entities\types\BlazePet;
use OguzhanUmutlu\ComplexPets\entities\types\CatPet;
use OguzhanUmutlu\ComplexPets\entities\types\DogPet;
use OguzhanUmutlu\ComplexPets\entities\types\GhastPet;
use OguzhanUmutlu\ComplexPets\entities\types\PandaPet;
use OguzhanUmutlu\ComplexPets\entities\types\PigPet;
use OguzhanUmutlu\ComplexPets\entities\types\WolfPet;
use OguzhanUmutlu\ComplexPets\entities\types\ParrotPet;
use OguzhanUmutlu\ComplexPets\items\CustomSpawnEgg;
use OguzhanUmutlu\ComplexPets\listener\EventListener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\item\ItemFactory;
use pocketmine\permission\Permission;
use pocketmine\permission\PermissionManager;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;

class ComplexPets extends PluginBase {
    /*** @var ComplexPets|null */
    public static $instance = null;
    /*** @var PetEntity[] */
    private static $petsSpawned = [];
    public const DEFAULT_PETS = [
        "WolfPet" => [
            "class" => WolfPet::class,
            "UiName" => "Wolf",
            "configName" => "wolf",
            "permission" => "wolf"
        ],
        "DogPet" => [
            "class" => DogPet::class,
            "UiName" => "Dog",
            "configName" => "dog",
            "permission" => "dog"
        ],
        "ParrotPet" => [
            "class" => ParrotPet::class,
            "UiName" => "Parrot",
            "configName" => "parrot",
            "permission" => "parrot"
        ],
        "CatPet" => [
            "class" => CatPet::class,
            "UiName" => "Cat",
            "configName" => "cat",
            "permission" => "cat"
        ],
        "PandaPet" => [
            "class" => PandaPet::class,
            "UiName" => "Panda",
            "configName" => "panda",
            "permission" => "panda"
        ],
        "PigPet" => [
            "class" => PigPet::class,
            "UiName" => "Pig",
            "configName" => "pig",
            "permission" => "pig"
        ],
        "AxolotlPet" => [
            "class" => AxolotlPet::class,
            "UiName" => "Axolotl",
            "configName" => "axolotl",
            "permission" => "axolotl"
        ],
        "BatPet" => [
            "class" => BatPet::class,
            "UiName" => "Bat",
            "configName" => "bat",
            "permission" => "bat"
        ],
        "BlazePet" => [
            "class" => BlazePet::class,
            "UiName" => "Blaze",
            "configName" => "blaze",
            "permission" => "blaze"
        ],
        "GhastPet" => [
            "class" => GhastPet::class,
            "UiName" => "Ghast",
            "configName" => "ghast",
            "permission" => "ghast"
        ]
    ];

    private static $pets = [];
    public static $conf = [];
    public function onEnable() {
        self::$instance = $this;
        self::$conf = $this->getConfig()->getAll();
        ItemFactory::registerItem(new CustomSpawnEgg(), true);
        $this->getServer()->getPluginManager()->registerEvents(new EventListener(), $this);
        foreach(self::DEFAULT_PETS as $name => $pet)
            self::registerPet($name, $pet["class"], $pet["UiName"], $pet["permission"], self::$conf["pets"][$pet["configName"]]);
        if(!InvMenuHandler::isRegistered())
            InvMenuHandler::register($this);
    }

    /*** @return array */
    public static function getPets(): array {
        return self::$pets;
    }

    /**
     * @param PetEntity $pet
     * @internal Only internal uses.
     */
    public static function addSpawnedPet(PetEntity $pet): void {
        self::$petsSpawned[$pet->getId()] = $pet;
    }

    /**
     * @param PetEntity $pet
     * @internal Only internal uses.
     */
    public static function removeSpawnedPet(PetEntity $pet): void {
        unset(self::$petsSpawned[$pet->getId()]);
    }

    public static function registerPet(string $name, string $className, string $UiName, string $permission, array $settings): void {
        if(isset(self::$pets[$name])) throw new BadMethodCallException("Pet named " . $name . " already exists!");
        self::$pets[$name] = [
            "class" => $className,
            "UiName" => $UiName,
            "settings" => $settings,
            "permission" => $permission
        ];
        PermissionManager::getInstance()->addPermission(new Permission("complex"."pets.cmd.".$permission));
        Entity::registerEntity($className, true, [$name]);
    }

    public static function unregisterPet(string $name): void {
        if(!isset(self::$pets[$name])) throw new BadMethodCallException("Pet named " . $name . " doesn't exists!");
        foreach(self::$petsSpawned as $pet)
            if(!$pet->isClosed() && get_class($pet) == self::$pets[$name]["class"])
                $pet->flagForDespawn();
        $perm = PermissionManager::getInstance()->getPermission("complex"."pets.cmd.".self::$pets[$name]["permission"]);
        if($perm)
            PermissionManager::getInstance()->removePermission($perm);
        unset(self::$pets[$name]);
    }

    /*** @return PetEntity[] */
    public static function getPetsSpawned(): array {
        return self::$petsSpawned;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if($command->getName() != "pets" || !$sender->hasPermission($command->getPermission()))
            return true;
        if($sender instanceof Player) {
            $petCount = 0;
            foreach(self::$petsSpawned as $pet)
                if($pet->owner == $sender->getName())
                    $petCount++;
            if($petCount >= self::$conf["pet-limit-per-player"]) {
                $sender->sendMessage("§c> You reached the pet limit!");
                return true;
            }
            $names = array_values(
                array_map(function($n){return $n["UiName"];}, array_filter(self::$pets, function($j) use ($sender) {
                    return $sender->hasPermission("complex"."pets.cmd.".$j["permission"]);
                }))
            );
            $sender->sendForm(new CustomForm(
                "Get pet",
                [
                    new Dropdown("pets", "Select pet type", $names, 0)
                ],
                function(Player $player, CustomFormResponse $response) use ($names): void {
                    $index = array_search($names[$response->getInt("pets")],
                        array_map(function($n){
                            return $n["UiName"];
                        }, self::$pets)
                    );
                    if(!is_string($index) || strlen($index) < 1) {
                        $player->sendMessage("§c> An error occurred while getting pet!");
                        return;
                    }
                    if(!$player->hasPermission(self::$pets[$index]["permission"])) {
                        $player->sendMessage("§c> You don't have permission to use this command!");
                        return;
                    }
                    Entity::createEntity($index, $player->level, new PetNBT($player, $player))->spawnToAll();
                }
            ));
        }
        return true;
    }
}