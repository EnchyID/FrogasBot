<?php

namespace OguzhanUmutlu\ComplexPets\entities\types;

use OguzhanUmutlu\ComplexPets\entities\PetEntity;

class CatPet extends PetEntity {
    public const NETWORK_ID = self::CAT;
    protected function initEntity(): void {
        parent::initEntity();
    }

    public function getName(): string {
        return "CatPet";
    }
}