<?php

namespace me\frogas\customshop;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\{CommandSender, Command};
use pocketmine\form\{CustomForm, CustomFormResponse, MenuForm};
use pocketmine\form\element\{Label, Slider};
use pocketmine\utils\{Config, TextFormat as TF};
use pocketmine\item\Item;
use onebone\economyapi\EconomyAPI;

class CustomShop extends PluginBase implements Listener {
	
	public $shop, $shop_data;
	public $prefix = "[CustomShop] ";
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->saveResource("shop_data.yml");
		$this->shop_data = new Config($this->getDataFolder() . "shop_data.yml", Config::YAML);
		$this->shop = $this->shop_data->getAll();
	}
	
	public function getPrefix(){
		return $this->prefix;
	}
	
	public function save(){
		$this->shop_data->setAll($this->shop);
		$this->shop_data->save();
	}
	
	public function onCommand(CommandSender $player, Command $cmd, string $label, array $args) : bool {
		switch($cmd->getName()){
			case "customshop":
			    if($player instanceof Player){
				    if(!isset($args[0])){
					    $player->sendMessage($this->getPrefix() . "Gunakan '/cshop [buy|list]' untuk menggunakan perintah!");
					    return true;
					}
					if($args[0] == "list"){
						$text = "Daftar nama toko yang ada:" . TF::EOL;
						foreach(array_keys($this->shop["shops"]) as $cat){
							$text .= $cat . ", ";
						}
						$player->sendMessage($text);
						return true;
					}
					if($args[0] == "buy"){
						if(!isset($args[0])){
					        $player->sendMessage($this->getPrefix() . "Gunakan '/cshop buy [nama toko]' untuk melihat barang ditoko!");
					        return true;
					    }
						if(isset($this->shop["shops"][$args[1]])){
					        $this->sendShop($player, $args[1]);
					        return true;
					    }
					    $player->sendMessage($this->getPrefix() . "Tidak ada toko dengan nama " . $args[1] . " Gunakan '/cshop list' untuk melihat semua daftar toko!");
						return true;
					}
				}
			break;
		}
		return true;
	}
	
	public function shopList(string $shop){
		$list = [];
		foreach(array_keys($this->shop["shops"][$shop]) as $items){
			$list[] = ["text" => $items];
		}
		return $list;
	}
	
	public function sendShop(Player $player, string $shop){
		$player->sendForm(new MenuForm(
		    "Toko " . $shop,
		    "Toko " . $shop . " menjual beberapa barang seperti daftar dibawah ini:",
		    $this->shopList($shop), function(Player $player, int $selected) use($shop) : void {
			    $item = $this->shopList($shop)[$selected]["text"];
			    $this->sendPurchase($player, $shop, $item);
			})
		);
	}
	
	public function sendPurchase(Player $player, string $shop, string $item){
		$player->sendForm(new CustomForm(
		    $item . TF::RESET . " Atur jumlah",
		    [
		        new Label("label", $item . TF::RESET . " Ingin membeli berapa?"),
		        new Slider("slider", "Jumlah", 1, $this->shop["shops"][$shop][$item]["count"])
		    ], function(Player $player, CustomFormResponse $response) use($shop, $item) : void {
			    $purse = $response->getFloat("slider") * $this->shop["shops"][$shop][$item]["price"];
			    if(EconomyAPI::getInstance()->myMoney($player) >= $purse){
				    EconomyAPI::getInstance()->reduceMoney($player, $purse);
				    $player->getInventory()->addItem(Item::get($this->shop["shops"][$shop][$item]["id"], $this->shop["shops"][$shop][$item]["meta"], $response->getFloat("slider"))->setCustomName($item));
				    $player->sendMessage($this->getPrefix() . "Berhasil membeli barang " . $item . TF::RESET . " dari toko " . $shop . " x" . $response->getFloat("slider") . " seharga " . $purse . ".");
				}else{
					$player->sendMessage($this->getPrefix() . "Uang kamu tidak cukup untuk membeli " . $item . TF::RESET . " x" . $response->getFloat("slider") . " seharga " . $purse . "! Sedangkan uang kamu berkisar " . EconomyAPI::getInstance()->myMoney($player) . "!");
				}
			})
		);
	}
}