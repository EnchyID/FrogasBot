<?php

namespace me\frogas\frogascrate;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\{ConsoleCommandSender, CommandSender, Command};
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\utils\{Config, TextFormat as TF};
use pocketmine\math\Vector3;
use jojoe77777\FormAPI\SimpleForm;

class FrogasCrate extends PluginBase implements Listener {
	
	public $prefix = "[Crate] > ";
	public $common = [];
	public $rare = [];
	public $legendary = [];
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->data = new Config($this->getDataFolder() . "crate.yml", Config::YAML);
	}
	
	public function onCommand(CommandSender $player, Command $cmd, string $label, array $args) : bool {
		switch($cmd->getName()){
			case "crate":
			    if($player instanceof Player){
				    if(empty($args[0])){
					    $player->sendMessage("Usage /crate [spawn|delete]");
					    return true;
					}
					switch($args[0]){
						case "spawn":
						    $this->crate[$player->getName()] = true;
						    $player->sendMessage($this->getPrefix() . "Destroy one block to spawned!");
                        break;
                        case "give":
                            if(empty($args[1])){
					            $player->sendMessage("Usage /crate spawn [common|rare|legendary]");
					            return true;
					        }
					        switch($args[1]){
						        case "common":
						            $this->addCommon($player, $args[2]);
						        break;
						        case "rare":
						            $this->addRare($player, $args[2]);
						        break;
						        case "legendary":
						            $this->addLegendary($player, $args[2]);
						        break;
						    }
						break;
                    }
				}else{
					$this->getServer()->getLogger()->info("Use command in server");
				}
			break;
		}
		return true;
	}
	
	public function getPrefix(){
		return $this->prefix;
	}
	
	public function getData(){
		return $this->data;
	}
	
	public function reduceCommon(Player $player, int $count){
		$this->common[$player->getName()] = --$count;
		$player->sendMessage($this->getPrefix() . "You have " . $count . " common crates!");
	}
	
	public function reduceRare(Player $player, int $count){
		$this->rare[$player->getName()] = --$count;
		$player->sendMessage($this->getPrefix() . "You have " . $count . " common crates!");
	}
	
	public function reduceLegendary(Player $player, int $count){
		$this->legendary[$player->getName()] = --$count;
		$player->sendMessage($this->getPrefix() . "You have " . $count . " common crates!");
	}
	
	public function addCommon(Player $player, int $count){
		$this->common[$player->getName()] = $count;
		$player->sendMessage($this->getPrefix() . "You have " . $count . " common crates!");
	}
	
	public function addRare(Player $player, int $count){
		$this->rare[$player->getName()] = $count;
		$player->sendMessage($this->getPrefix() . "You have " . $count . " rare crates!");
	}
	
	public function addLegendary(Player $player, int $count){
		$this->legendary[$player->getName()] = $count;
		$player->sendMessage($this->getPrefix() . "You have " . $count . " rare crates!");
	}
	
	public function setCrate(int $x, int $y, int $z){
		$this->getData()->set("crate-X", $x);
		$this->getData()->set("crate-Y", $y);
		$this->getData()->set("crate-Z", $z);
		$this->getData()->save();
    }

     public function delCrate(){
		$this->getData()->remove("crate-X");
		$this->getData()->remove("crate-Y");
		$this->getData()->remove("crate-Z");
		$this->getData()->save();
    }
	
	public function onBreakEvent(BlockBreakEvent $event){
		$player = $event->getPlayer();
		$block = $event->getBlock();
		if(isset($this->crate[$player->getName()])){
			$x = $block->getX();
			$y = $block->getY();
			$z = $block->getZ();
			if(empty($this->getData()->get("crate-X") && $this->getData()->get("crate-Y") && $this->getData()->get("crate-Z"))){
				$this->setCrate($x, $y, $z);
				unset($this->crate[$player->getName()]);
				$text = TF::AQUA . "Frogas Crate" . TF::EOL . TF::GRAY . "TAP TO VIEW";
                $block->getLevel()->addParticle(new FloatingTextParticle(new Vector3($x + 0.5, $y + 2, $z + 0.5), "", $text));
				$block->getLevel()->setBlockIdAt($x, $y + 1, $z, 120);
				$player->sendMessage($this->getPrefix() . "Crate has spawned for this locations!");
		    }else{
			    $player->sendMessage($this->getPrefix() . "Crate already spawned for this locations!");
			    unset($this->crate[$player->getName()]);
			}
			$event->setCancelled();
			return;
			if(!empty($this->getData()->get("crate-X") && $this->getData()->get("crate-Y") && $this->getData()->get("crate-Z"))){
				$x = $this->getData()->get("crate-X");
		        $y = $this->getData()->get("crate-Y");
		        $z = $this->getData()->get("crate-Z");
		        if($block->x == $x && $block->y == $y + 2 && $block->z == $z || $block->x == $x && $block->y == $y + 1  && $block->z == $z){
			        if($player->isOp()){
				         $this->delCrate();
				         $player->sendMessage($this->getPrefix() . "Crate has been removed!");
				    }else{
					    $event->setCancelled();
					    $player->sendMessage($this->getPrefix() . "You dont have access to removed this crate!");
					}
				}
		    }
		}
	}
	
	public function onTouchCrate(PlayerInteractEvent $event){
		$player = $event->getPlayer();
		$block = $event->getBlock();
		$x = $this->getData()->get("crate-X");
		$y = $this->getData()->get("crate-Y");
		$z = $this->getData()->get("crate-Z");
		if($block->x == $x && $block->y == $y + 2 && $block->z == $z || $block->x == $x && $block->y == $y + 1  && $block->z == $z){
		    $this->openCrate($player);
		}
	}
	
	public function openCrate(Player $player){
		$form = new SimpleForm(function(Player $player, $data){
			$result = $data;
			if($result === null){
				return true;
			}
			switch($result){
				case 0:
				    $this->openCrateCommon($player);
				break;
				case 1:
				    $this->openCrateRare($player);
				break;
				case 2:
				    $this->openCrateLegendary($player);
				break;
			}
		});
		$form->setTitle("Frogas Crate");
		$form->setContent("Please select a crate to view.");
		$form->addButton("» " . TF::GREEN . "Common Crate" . TF::EOL . TF::GRAY . "TAP TO VIEW");
		$form->addButton("» " . TF::YELLOW . "Rare Crate" . TF::EOL . TF::GRAY . "TAP TO VIEW");
		$form->addButton("» " . TF::RED . "Legendary Crate" . TF::EOL . TF::GRAY . "TAP TO VIEW");
		$form->sendToPlayer($player);
	}
	
	public function openCrateCommon(Player $player){
		$form = new SimpleForm(function(Player $player, $data){
			$result = $data;
			if($result === null){
				return true;
			}
			switch($result){
				case 0:
				    $array = array("ST.Mining", "ST.Survive", "ST.Strong");
				    $rand = $array[array_rand($array)];
				    if($this->common[$player->getName()] >= 5){
					    $this->reduceCommon($player, 5);
					    $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "setuperm " . $player->getName() . " " . $rand);
					    $player->sendMessage($this->getPrefix() . "You has have " . $rand . " permission!");
					}else{
						$player->sendMessage($this->getPrefix() . "You dont enough common key crate to open!");
					}
				break;
				case 1:
				    $this->openCrate($player);
				break;
			}
		});
		$form->setTitle("Crate » Common");
		$form->setContent("» You have " . $this->common[$player->getName()] . " key.");
		$form->addButton("» " . TF::GREEN . "Open Crate" . TF::EOL . TF::GRAY . "x5 Key Crate");
		$form->addButton("» " . TF::RED . "Back");
		$form->sendToPlayer($player);
	}
	
	public function openCrateRare(Player $player){
		$form = new SimpleForm(function(Player $player, $data){
			$result = $data;
			if($result === null){
				return true;
			}
			switch($result){
				case 0:
				    $array = array("ST.Mining", "ST.Survive", "ST.Strong");
				    $rand = $array[array_rand($array)];
				    if($this->rare[$player->getName()] >= 5){
					    $this->reduceRare($player, 5);
					    $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "setuperm " . $player->getName() . " " . $rand);
					    $player->sendMessage($this->getPrefix() . "You has have " . $rand . " permission!");
					}else{
						$player->sendMessage($this->getPrefix() . "You dont enough common key crate to open!");
					}
				break;
				case 1:
				    $this->openCrate($player);
				break;
			}
		});
		$form->setTitle("Crate » Rare");
		$form->setContent("» You have " . $this->rare[$player->getName()] . " key.");
		$form->addButton("» " . TF::GREEN . "Open Crate" . TF::EOL . TF::GRAY . "x5 Key Crate");
		$form->addButton("» " . TF::RED . "Back");
		$form->sendToPlayer($player);
	}
	
	public function openCrateLegendary(Player $player){
		$form = new SimpleForm(function(Player $player, $data){
			$result = $data;
			if($result === null){
				return true;
			}
			switch($result){
				case 0:
				    $array = array("ST.Mining", "ST.Survive", "ST.Strong");
				    $rand = $array[array_rand($array)];
				    if($this->legendary[$player->getName()] >= 5){
					    $this->reduceLegendary($player, 5);
					    $this->getServer()->dispatchCommand(new ConsoleCommandSender(), "setuperm " . $player->getName() . " " . $rand);
					    $player->sendMessage($this->getPrefix() . "You has have " . $rand . " permission!");
					}else{
						$player->sendMessage($this->getPrefix() . "You dont enough common key crate to open!");
					}
				break;
				case 1:
				    $this->openCrate($player);
				break;
			}
		});
		$form->setTitle("Crate » Legendary");
		$form->setContent("» You have " . $this->legendary[$player->getName()] . " key.");
		$form->addButton("» " . TF::GREEN . "Open Crate" . TF::EOL . TF::GRAY . "x5 Key Crate");
		$form->addButton("» " . TF::RED . "Back");
		$form->sendToPlayer($player);
	}
}