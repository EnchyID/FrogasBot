<?php

namespace me\frogas\adoptme\event;

use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\player\PlayerJoinEvent;
use me\frogas\adoptme\AdoptMe;

class PlayerJoinBabyEvent implements Listener {
	
	private $plugin;
	
	public function __construct(AdoptMe $plugin){
		$this->plugin = $plugin;
	}
	
	public function getLoader() : AdoptMe {
		return $this->plugin;
    }
    
    public function onJoinPlayerEvent(PlayerJoinEvent $event){
    	$player = $event->getPlayer();
        if(empty($this->getLoader()->adopt[$player->getName()])){
            $this->getLoader()->createAccount($player->getName());
        }else{
        	if(isset($this->getLoader()->adopt[$player->getName()])){
            	$player->setNameTag($player->getName());
                foreach($this->getLoader()->getAdoptAll($player->getName()) as $owner){
                	$player->setScoreTag("Was adopt by " . TF::RED . $owner);
                    $player->setScale($this->getLoader()->adopt[$owner][$player->getName()]["scale"]);
                }
            }
        }
    }
}