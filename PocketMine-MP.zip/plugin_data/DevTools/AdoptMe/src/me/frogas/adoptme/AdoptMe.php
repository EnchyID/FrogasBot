<?php

namespace me\frogas\adoptme;

use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\utils\{Config, TextFormat as TF};
use me\frogas\adoptme\command\AdoptMeCommand;
use me\frogas\adoptme\event\{PlayerDamagerEvent, PlayerJoinBabyEvent, PlayerQuitBabyEvent, PlayerMoveBabyEvent};
use me\frogas\adoptme\task\AdoptTask;
use Scoreboards\Scoreboards;

class AdoptMe extends PluginBase implements Listener {
	
	public $adopt, $setting;
	public $prefix = TF::GRAY . "(" . TF::LIGHT_PURPLE . "AdoptMe" . TF::GRAY . ")" . TF::WHITE . " > ";
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getServer()->getCommandMap()->register("adopt", new AdoptMeCommand("adopt", $this));
		$this->getServer()->getLogger()->info($this->getPrefix() . "Enable by @Frogas");
		$this->getScheduler()->scheduleRepeatingTask(new AdoptTask($this), 5);
		$this->adopt_data = new Config($this->getDataFolder() . "adopt.yml", Config::YAML);
		$this->setting_data = new Config($this->getDataFolder() . "setting.yml", Config::YAML);
		$this->adopt = $this->adopt_data->getAll();
		$this->setting = $this->setting_data->getAll();
		$this->registerEvents();
	}
	
	public function registerEvents(){
		$this->getServer()->getPluginManager()->registerEvents(new PlayerDamagerEvent($this), $this);
		$this->getServer()->getPluginManager()->registerEvents(new PlayerJoinBabyEvent($this), $this);
		$this->getServer()->getPluginManager()->registerEvents(new PlayerQuitBabyEvent($this), $this);
		$this->getServer()->getPluginManager()->registerEvents(new PlayerMoveBabyEvent($this), $this);
	}
	
	public function saveAll(){
		$this->adopt_data->setAll($this->adopt);
		$this->setting_data->setAll($this->setting);
		$this->adopt_data->save();
		$this->setting_data->save();
	}
	
	public function addHud(){
		foreach($this->getServer()->getLevels() as $level){
			foreach($level->getEntities() as $player){
				if($player instanceof Player){
					if(isset($this->adopt[$player->getName()])){
				        foreach($this->getAdoptAll($player->getName()) as $baby){
				            $player->sendTip(TF::YELLOW . "» " . TF::WHITE . "Level: " . TF::AQUA . $this->getBabyLevel($baby, $player->getName()) . TF::WHITE . " ExpLevel: " . TF::AQUA . $this->getBabyExp($baby, $player->getName()) . "%");
				        }
					}
				}
			}
		}
	}
	
	public function getPrefix(){
		return $this->prefix;
	}
	
	public function setScoreboard(){
		foreach($this->getServer()->getLevels() as $level){
			foreach($level->getEntities() as $player){
				if($player instanceof Player){
					if(isset($this->adopt[$player->getName()])){
				        foreach($this->getAdoptAll($player->getName()) as $baby){
					        $name = $this->getServer()->getPlayer($baby);
					        if($name){
						        if($this->getScoreboardSetting($player->getName(), $baby) == true){
					                $scoreboard = Scoreboards::getInstance();
		                            $scoreboard->new($player, "dummy", TF::GREEN . " BABY STATS ");
		                            $scoreboard->setLine($player, 1, " ");
		                            $scoreboard->setLine($player, 2, TF::GREEN . " - " . TF::WHITE . "Health: " . TF::AQUA . $name->getHealth() . TF::WHITE . "pc ");
		                            $scoreboard->setLine($player, 3, TF::GREEN . " - " . TF::WHITE . "Food: " . TF::AQUA . $name->getFood() . TF::WHITE . "pc ");
		                            $scoreboard->setLine($player, 4, TF::GREEN . " - " . TF::WHITE . "Gamemode: " . TF::AQUA . $name->getGamemode() . TF::WHITE . " ");
		                            $scoreboard->setLine($player, 5, TF::GREEN . " - " . TF::WHITE . "Location: ");
		                            $scoreboard->setLine($player, 6, TF::WHITE . " X: " . TF::AQUA . intval($name->getX()) . TF::WHITE . " Y: " . TF::AQUA . intval($name->getY()) . TF::WHITE . " Z: " . TF::AQUA . intval($name->getZ()) . " ");
		                            $scoreboard->setLine($player, 7, "  ");
		                            $scoreboard->setLine($player, 8, TF::GREEN . " ADOPTME ");
		                        }
		                    }
					    }
					}
				}
			}
		}
	}
	
	public function delScoreboard(Player $player){
		return Scoreboards::getInstance()->remove($player);
	}
	
	public function createAccount(string $name) : void {
		if($this->existsAccount($name)){
			return;
		}
		$this->setOwnerBaby($name, 0.5, 0, "Specter", 0);
		$this->setAdoptSetting($name, "Specter", true, true, true);
	}

	public function existsAccount(string $name) : bool {
		return isset($this->adopt[$name]);
	}
	
	public function setAdoptSetting(string $name, string $baby, bool $move, bool $damager, bool $scoreboard){
		$this->setting[$name][$baby] = [
		    "movement" => $move,
		    "damager" => $damager,
		    "scoreboard" => $scoreboard
		];
		$this->setBabySetting($baby, $name, $move, $damager, $scoreboard);
		$this->saveAll();
	}
	
	public function setBabySetting(string $baby, string $name, bool $move, bool $damager, bool $scoreboard){
		$this->setting[$baby][$name] = [
		    "movement" => $move,
		    "damager" => $damager,
		    "scoreboard" => $scoreboard
		];
		$this->saveAll();
	}
	
	public function setOwnerBaby(string $name, int $scale, int $level, string $baby, int $exp){
		$this->adopt[$name][$baby] = [
		    "scale" => $scale,
		    "level" => $level,
		    "exp" => $exp
		];
		$this->setAdoptBaby($baby, $scale, $level, $name, $exp);
		$this->saveAll();
	}

    public function setAdoptBaby(string $baby, int $scale, int $level, string $name, int $exp){
    	$this->adopt[$baby][$name] = [
            "scale" => $scale,
            "level" => $level,
            "exp" => $exp
        ];
        $this->saveAll();
    }
    
    public function delOwnerBaby(string $name, string $baby){
		unset($this->adopt[$name][$baby]);
		$this->delAdoptBaby($baby, $name);
		$this->saveAll();
	}
	
	public function delAdoptBaby(string $baby, string $name){
		unset($this->adopt[$baby][$name]);
		$this->saveAll();
	}
	
	public function getMovementSetting(string $name, string $baby){
		return $this->setting[$name][$baby]["movement"];
	}
	
	public function getScoreboardSetting(string $name, string $baby){
		return $this->setting[$name][$baby]["scoreboard"];
	}
	
	public function getDamagerSetting(string $name, string $baby){
		return $this->setting[$name][$baby]["damager"];
	}
    
    public function getBabyOwner(string $baby, string $name){
    	return isset($this->adopt[$baby][$name]);
    }
    
    public function getAdoptBaby(string $name, string $baby){
    	return isset($this->adopt[$name][$baby]);
    }
    
    public function getBabyLevel(string $baby, string $name){
    	return $this->adopt[$baby][$name]["level"];
    }
    
    public function getAdoptLevel(string $name, string $baby){
    	return $this->adopt[$name][$baby]["level"];
    }
    
    public function getBabyScale(string $baby, string $name){
    	return $this->adopt[$baby][$name]["scale"];
    }
    
    public function getAdoptScale(string $name, string $baby){
    	return $this->adopt[$name][$baby]["scale"];
    }
    
    public function getBabyExp(string $baby, string $name){
    	return $this->adopt[$baby][$name]["exp"];
    }
    
    public function getAdoptExp(string $name, string $baby){
    	return $this->adopt[$name][$baby]["exp"];
    }
    
    public function getOnlinePlayers() : array {
    	$list = [];
        foreach($this->getServer()->getOnlinePlayers() as $online){
        	$list[] = $online->getName();
        }
        return $list;
    }
    
    public function getAdoptAll(string $name) : array {
    	$adopt = [];
        foreach(array_keys($this->adopt[$name]) as $baby){
        	$adopt[] = $baby;
        }
        return $adopt;
    }
    
    public function getBabyAll(string $baby) : array {
    	$adopt = [];
        foreach(array_keys($this->adopt[$baby]) as $owner){
        	$adopt[] = $owner;
        }
        return $adopt;
    }
    
    public function setAdoptExp(string $name, string $baby){
    	$this->adopt[$name][$baby] = [
            "scale" => $this->getAdoptScale($name, $baby),
            "level" => $this->getAdoptLevel($name, $baby),
            "exp" => $this->getAdoptExp($name, $baby) + 1
        ];
        $this->saveAll();
    }
    
    public function setBabyExp(string $baby, string $name){
    	$this->adopt[$baby][$name] = [
            "scale" => $this->getBabyScale($baby, $name),
            "level" => $this->getBabyLevel($baby, $name),
            "exp" => $this->getBabyExp($baby, $name) + 1
        ];
        $this->saveAll();
    }
    
    public function setAdoptLevel(string $name, string $baby){
    	$this->adopt[$name][$baby] = [
            "scale" => $this->getAdoptScale($name, $baby),
            "level" => $this->getAdoptLevel($name, $baby) + 1,
            "exp" => $this->getAdoptExp($name, $baby)
        ];
        $this->saveAll();
    }
    
    public function setBabyLevel(string $baby, string $name){
    	$this->adopt[$baby][$name] = [
            "scale" => $this->getBabyScale($baby, $name),
            "level" => $this->getBabyLevel($baby, $name) + 1,
            "exp" => $this->getBabyExp($baby, $name)
        ];
        $this->saveAll();
    }
    
    public function setAdoptScale(string $name, string $baby){
    	$this->adopt[$name][$baby] = [
            "scale" => 1,
            "level" => $this->getAdoptLevel($name, $baby),
            "exp" => $this->getAdoptExp($name, $baby)
        ];
        $this->saveAll();
    }
    
    public function setBabyScale(string $baby, string $name){
    	$this->adopt[$baby][$name] = [
            "scale" => 1,
            "level" => $this->getBabyLevel($baby, $name),
            "exp" => $this->getBabyExp($baby, $name)
        ];
        $this->saveAll();
    }
    
    public function resetAdoptExp(string $name, string $baby){
    	$this->adopt[$name][$baby] = [
            "scale" => $this->getAdoptScale($name, $baby),
            "level" => $this->getAdoptLevel($name, $baby),
            "exp" => 0
        ];
        $this->saveAll();
    }
    
    public function resetBabyExp(string $baby, string $name){
    	$this->adopt[$baby][$name] = [
            "scale" => $this->getBabyScale($baby, $name),
            "level" => $this->getBabyLevel($baby, $name),
            "exp" => 0
        ];
        $this->saveAll();
    }
}