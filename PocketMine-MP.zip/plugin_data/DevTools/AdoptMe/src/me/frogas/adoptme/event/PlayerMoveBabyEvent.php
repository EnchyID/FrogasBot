<?php

namespace me\frogas\adoptme\event;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use me\frogas\adoptme\AdoptMe;

class PlayerMoveBabyEvent implements Listener {
	
	private $plugin;
	
	public function __construct(AdoptMe $plugin){
		$this->plugin = $plugin;
	}
	
	public function getLoader() : AdoptMe {
		return $this->plugin;
    }
    
    public function onMovePlayerEvent(PlayerMoveEvent $event){
    	$player = $event->getPlayer();
    	if(isset($this->getLoader()->adopt[$player->getName()])){
            foreach($this->getLoader()->getBabyAll($player->getName()) as $baby){
            	if($this->getLoader()->getServer()->getPlayer($baby)){
            	    if($this->getLoader()->getMovementSetting($player->getName(), $baby) == true){
            	        $event->setCancelled(false);
                    }else{
                    	$event->setCancelled(true);
                    }
                }
            }
        }
    }
}