const mineflayer = require("mineflayer");
const { pathfinder, Movements, goals } = require("mineflayer-pathfinder");
const GoalFollow = require("mineflayer-pathfinder").goals;
var config = require("./config.json");
const bot = mineflayer.createBot({ 
	host: config.host,
	port: config.port,
    username: config.username
});

bot.once("spawn", () => {
    const mcData = require("minecraft-data")(bot.version);
    const defaultMovs = new Movements(bot, mcData);
    const playerFilter = (entity) => entity.type === "player";
    const playerEntity = bot.nearestEntity(playerFilter);
    if(!playerEntity) return;
    const pos = playerEntity.position.offset(0, playerEntity.height, 0);
    bot.lookAt(pos);
});

bot.on("chat", (username, message) => {
	const args = message.split(" ");
	const prefix = config.prefix;
	if(args[0] === prefix + "item_id"){
		const id = mcData.itemsByName[args[1]].id;
		bot.chat("The item id of " + args[1] + " is " + id);
	}
	if(args[0] === prefix + "halo"){
		bot.chat("Hallo aku babunya Ezaaaa");
	}
	if(args[0] === prefix + "follow"){
		const target = bot.players[username] ? bot.players[username].entity : null; 
		if(!target){
            bot.chat("Where are you? " + target);
            return;
        }      
        bot.pathfinder.setMovements(defaultMove);
        bot.pathfinder.setGoal(new GoalFollow(target, 3), true);
    }
    if(args[0] === prefix + "rules"){
    	bot.chat("- Jangan rusuh!");
    }
});