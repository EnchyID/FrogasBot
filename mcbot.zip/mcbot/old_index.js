const mineflayer = require("mineflayer");
const { pathfinder, Movements, goals } = require("mineflayer-pathfinder");
const { GoalNear, GoalBlock, GoalXZ, GoalY, GoalInvert, GoalFollow, GoalBreakBlock, GoalPlaceBlock } = require("mineflayer-pathfinder").goals;
var config = require("./config.json");
const bot = mineflayer.createBot({ 
	host: config.host,
	port: config.port,
    username: config.username
});

bot.once("spawn", () => {
    const mcData = require("minecraft-data")(bot.version);
    const defaultMove = new Movements(bot, mcData);
    bot.on("chat", (username, message) => {
        if(username === bot.username) return;
        const target = bot.players[username] ? bot.players[username].entity : null;
        switch(message){
        	case "menu":
                bot.chat(
                    " §d+------------------------------------------------------+\n" +
                    "§d| §acome §f- §aFor bot to your fast.\n" +
                    "§d| §afollow §f- §aFor bot followed with you.\n" +
                    "§d| §aavoid §f- §aBot avoid in world.\n" +
                    "§d| §abreak §f- §aFor bot break a block.\n" +
                    "§d| §ahit §f- §aFor bot hit a mob and more.\n" +
                    " §d+------------------------------------------------------+\n" +
                    "§d| §aTo stop all action you can chat §c'stop'"
                );
            break;
        	case "come":
                if(!target){
                	bot.chat("§cAku tidak bisa melihat kamu :(");
                    return;
                }
                const pt = target.position;
                bot.pathfinder.setMovements(defaultMove);
                bot.pathfinder.setGoal(new GoalNear(pt.x, pt.y, pt.z, 1));
            break;
            case "follow":
                if(!target){
                    bot.chat("§eAku tidak bisa melihat kamu :(");
                    return;
                }
                bot.pathfinder.setMovements(defaultMove);
                bot.pathfinder.setGoal(new GoalFollow(target, 3), true);
            break;
            case "avoid":
                if(!target){
                    bot.chat("§eAku tidak bisa melihat kamu :(");
                    return;
                }
                bot.pathfinder.setMovements(defaultMove);
                bot.pathfinder.setGoal(new GoalInvert(new GoalFollow(target, 5)), true);
            break;
            case "stop":
                bot.pathfinder.stop();
            break;
            case "hit":
                const mobFilter = e => e.type === "mob" && e.mobType === "Zombie";
                const mob = bot.nearestEntity(mobFilter);
                if(!mob) return;
                bot.lookAt(mob.position, true, () => {
                    bot.attack(mob);
                });
            break;
            case "break":
                if(!target){
                    bot.chat("§eAku tidak bisa melihat kamu :(");
                    return;
                }
                const p = target.position.offset(0, -1, 0);
                const goal = new GoalBreakBlock(p.x, p.y, p.z, bot);
                bot.pathfinder.goto(goal).then(() => {
                    bot.dig(bot.blockAt(p), "raycast").catch(err => console.error("digging error", err))
                }, (err) => {
                    console.error("Pathfing error", err);
                });
            break;
        }
    });
    setInterval(() => {
        const mobFilter = e => e.type === "mob" && e.mobType === "Zombie";
        const mob = bot.nearestEntity(mobFilter);
        if(!mob) return;
        const pos = mob.position;
        bot.lookAt(pos, true, () => {
            bot.attack(mob);
        });
    }, 1000);
    lookAtNearestPlayer(); 
});

function lookAtNearestPlayer(){
    const playerFilter = (entity) => entity.type === "player";
    const playerEntity = bot.nearestEntity(playerFilter);
    if(!playerEntity) return;
    const pos = playerEntity.position.offset(0, playerEntity.height, 0);
    bot.lookAt(pos);
}

bot.loadPlugin(pathfinder);